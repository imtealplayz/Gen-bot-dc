import { z } from 'zod';
import { botLogs } from './schema';

export const api = {
  bot: {
    status: {
      method: 'GET' as const,
      path: '/api/bot/status',
      responses: {
        200: z.object({
          online: z.boolean(),
          tag: z.string().nullable(),
          guilds: z.number(),
        }),
      },
    },
    logs: {
      method: 'GET' as const,
      path: '/api/bot/logs',
      responses: {
        200: z.array(z.custom<typeof botLogs.$inferSelect>()),
      },
    },
  },
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
