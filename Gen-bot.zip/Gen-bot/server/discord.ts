import { Client, GatewayIntentBits, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType, EmbedBuilder } from 'discord.js';
import { storage } from './storage';

export const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
  ],
});

// Cooldown storage
const cooldowns = new Map<string, number>();

  client.once('ready', async () => {
  const message = `Logged in as ${client.user?.tag}!`;
  console.log(message);
  await storage.createBotLog(message);
  
  // Grant 100,000 to special user only
  try {
    const targetUserId = "926063716057894953";
    await storage.updateDiscordUserGenies(targetUserId, 100000);
    console.log(`Granted 100,000 Gens to ${targetUserId}`);
  } catch (err) {
    console.error('Failed to grant gens:', err);
  }
});

client.on('error', async (error) => {
  console.error('Discord client error:', error);
  await storage.createBotLog(`Discord client error: ${error.message}`);
});

client.on('disconnect', async () => {
  const message = 'Discord bot disconnected';
  console.log(message);
  await storage.createBotLog(message);
});

client.on('messageCreate', async (message) => {
  if (message.author.bot) return;
  
  const prefix = ';';
  if (!message.content.startsWith(prefix)) return;

  const args = message.content.slice(prefix.length).trim().split(/ +/);
  const command = args.shift()?.toLowerCase();

  if (command === 'ping') {
    try {
      await storage.createBotLog(`Received !ping from ${message.author.tag}`);
      await message.reply('Pong!');
    } catch (error) {
      console.error('Error responding to !ping:', error);
    }
    return;
  }

  // Handle timeout/to command
  if (command === 'timeout' || command === 'to') {
    try {
      const target = message.mentions.members?.first() || 
                     message.guild?.members.cache.get(args[0]) ||
                     message.guild?.members.cache.find(m => m.user.username.toLowerCase() === args[0]?.toLowerCase()) ||
                     message.guild?.members.cache.find(m => m.displayName.toLowerCase() === args[0]?.toLowerCase());

      if (!target) {
        return message.reply('User not found. Usage: `;timeout <user/id/name> <time><s|m|h> [reason]`');
      }

      const timeStr = args[1];
      if (!timeStr) {
        return message.reply('Please specify a time. E.g., `10m`, `1h`, `30s`');
      }

      const match = timeStr.match(/^(\d+)([smh])$/);
      if (!match) {
        return message.reply('Invalid time format. Use something like `10m`, `1h`, or `30s`.');
      }

      const amount = parseInt(match[1]);
      const unit = match[2];
      let durationMs = 0;

      if (unit === 's') durationMs = amount * 1000;
      else if (unit === 'm') durationMs = amount * 60 * 1000;
      else if (unit === 'h') durationMs = amount * 60 * 60 * 1000;

      if (durationMs > 2419200000) {
        return message.reply('Timeout duration cannot exceed 28 days.');
      }

      const reason = args.slice(2).join(' ') || 'no reason';

      if (!message.member?.permissions.has('ModerateMembers')) {
        return message.reply('You do not have permission to timeout members.');
      }

      if (!target.moderatable) {
        return message.reply('I cannot timeout this user. They might have a higher role than me.');
      }

      await target.timeout(durationMs, reason);
      const logMsg = `**${target.user.username}** has been put on a timeout for ${timeStr} **${reason}**`;
      await storage.createBotLog(logMsg);
      await message.reply({ content: logMsg, allowedMentions: { repliedUser: false } });

    } catch (error) {
      console.error('Error in timeout command:', error);
    }
    return;
  }

  // Handle kick command
  if (command === 'kick') {
    try {
      const target = message.mentions.members?.first() || 
                     message.guild?.members.cache.get(args[0]) ||
                     message.guild?.members.cache.find(m => m.user.username.toLowerCase() === args[0]?.toLowerCase()) ||
                     message.guild?.members.cache.find(m => m.displayName.toLowerCase() === args[0]?.toLowerCase());

      if (!target) {
        return message.reply({ content: 'User not found. Usage: `;kick <user/id/name> [reason]`', allowedMentions: { repliedUser: false } });
      }

      const reason = args.slice(1).join(' ') || 'no reason';

      if (!message.member?.permissions.has('KickMembers')) {
        return message.reply({ content: 'You do not have permission to kick members.', allowedMentions: { repliedUser: false } });
      }

      if (!target.kickable) {
        return message.reply({ content: 'I cannot kick this user. They might have a higher role than me.', allowedMentions: { repliedUser: false } });
      }

      await target.kick(reason);
      const logMsg = `**${target.user.username}** has been kicked for **${reason}**`;
      await storage.createBotLog(logMsg);
      await message.reply({ content: logMsg, allowedMentions: { repliedUser: false } });

    } catch (error) {
      console.error('Error in kick command:', error);
    }
    return;
  }

  // Handle ban command
  if (command === 'ban') {
    try {
      const target = message.mentions.members?.first() || 
                     message.guild?.members.cache.get(args[0]) ||
                     message.guild?.members.cache.find(m => m.user.username.toLowerCase() === args[0]?.toLowerCase()) ||
                     message.guild?.members.cache.find(m => m.displayName.toLowerCase() === args[0]?.toLowerCase());

      if (!target) {
        return message.reply({ content: 'User not found. Usage: `;ban <user/id/name> [reason]`', allowedMentions: { repliedUser: false } });
      }

      const reason = args.slice(1).join(' ') || 'no reason';

      if (!message.member?.permissions.has('BanMembers')) {
        return message.reply({ content: 'You do not have permission to ban members.', allowedMentions: { repliedUser: false } });
      }

      if (!target.bannable) {
        return message.reply({ content: 'I cannot ban this user. They might have a higher role than me.', allowedMentions: { repliedUser: false } });
      }

      await target.ban({ reason });
      const logMsg = `**${target.user.username}** has been banned for **${reason}**`;
      await storage.createBotLog(logMsg);
      await message.reply({ content: logMsg, allowedMentions: { repliedUser: false } });

    } catch (error) {
      console.error('Error in ban command:', error);
    }
    return;
  }

  // Handle convert command
  if (command === 'convert') {
    try {
      const gemAmount = parseInt(args[0]);
      if (isNaN(gemAmount) || gemAmount <= 0) {
        return message.reply("Usage: `;convert <amount of Gems>`");
      }

      const discordUser = await storage.getDiscordUser(message.author.id);
      if (discordUser.gems < gemAmount) {
        return message.reply(`You don't have enough Gems! You only have **${discordUser.gems}** 💎.`);
      }

      const gensGained = gemAmount * 1000;
      const newGems = discordUser.gems - gemAmount;
      const newGens = discordUser.genies + gensGained;

      await storage.updateDiscordUserGems(message.author.id, newGems);
      await storage.updateDiscordUserGenies(message.author.id, newGens);

      await message.reply({
        content: `<@${message.author.id}> you have successfully converted **${gemAmount}** Gems 💎 into **${gensGained}** Gens 💵. Your current balance is **${newGens}** Gens 💵.`,
        allowedMentions: { users: [message.author.id], repliedUser: false }
      });
    } catch (error) {
      console.error('Error in convert command:', error);
    }
    return;
  }
  if (command === 'bal' || command === 'balance') {
    try {
      const discordUser = await storage.getDiscordUser(message.author.id);
      await message.reply({ 
        content: `<@${message.author.id}>, you currently have:\n💵 **${discordUser.genies}** Gens\n💎 **${discordUser.gems}** Gems`,
        allowedMentions: { users: [message.author.id], repliedUser: false } 
      });
    } catch (error) {
      console.error('Error in bal command:', error);
    }
    return;
  }

  // Handle Leaderboard command
  if (command === 'lb' || command === 'leaderboard') {
    try {
      const allUsers = await storage.getAllDiscordUsers();
      const top10 = allUsers
        .sort((a, b) => b.genies - a.genies)
        .slice(0, 10);

      if (top10.length === 0) {
        return message.reply("The leaderboard is currently empty!");
      }

      let leaderboardText = "";
      for (let i = 0; i < top10.length; i++) {
        const user = top10[i];
        let username = "Unknown User";
        try {
          const fetchedUser = await client.users.fetch(user.id);
          username = fetchedUser.username;
        } catch (err) {
          username = `User(${user.id})`;
        }
        const rank = i + 1;
        const crown = i === 0 ? "👑 " : "";
        leaderboardText += `${rank}. ${crown}**${username}** — ${user.genies} Gens\n`;
      }

      const embed = new EmbedBuilder()
        .setTitle('🏆 Top 10 Gens Leaderboard')
        .setDescription(leaderboardText)
        .setColor(0x00FFFF) // Electric Blue
        .setTimestamp();

      await message.reply({ embeds: [embed], allowedMentions: { repliedUser: false } });
    } catch (error) {
      console.error('Error in lb command:', error);
    }
    return;
  }

  // Handle Daily command
  if (command === 'daily') {
    try {
      const now = new Date();
      // IST is UTC+5:30
      const istTime = new Date(now.getTime() + (5.5 * 60 * 60 * 1000));
      
      // Reset is at 12 AM IST. 
      // The "current daily cycle" is identified by the date string in IST
      const istDateStr = istTime.toISOString().split('T')[0];

      const user = await storage.getDiscordUser(message.author.id);
      
      if (user.lastClaimedDate === istDateStr) {
        // Calculate time until next 12 AM IST
        const nextReset = new Date(istTime);
        nextReset.setUTCHours(0, 0, 0, 0);
        nextReset.setDate(nextReset.getDate() + 1);
        
        const diffMs = nextReset.getTime() - istTime.getTime();
        const hours = Math.floor(diffMs / (1000 * 60 * 60));
        const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((diffMs % (1000 * 60)) / 1000);

        return message.reply({ 
          content: `you have already claimed your daily reward! You can claim it again in **${hours}h ${minutes}m ${seconds}s** (12 AM IST)`,
          allowedMentions: { repliedUser: false } 
        });
      }

      const newBalance = user.genies + 500;
      await storage.updateDiscordUserGenies(message.author.id, newBalance);
      await (storage as any).updateDiscordUserClaim(message.author.id, istDateStr);

      await message.reply({ 
        content: `You have claimed your daily **500** Gens! Your new balance is **${newBalance}** Gens.`,
        allowedMentions: { repliedUser: false } 
      });

    } catch (error) {
      console.error('Error in daily command:', error);
    }
    return;
  }

  // Handle Crime, Work, and Beg commands
  if (command === 'crime' || command === 'work' || command === 'beg') {
    try {
      const now = Date.now();
      const lastUsed = cooldowns.get(`${message.author.id}-${command}`) || 0;
      const cooldownTime = 30000; // 30 seconds cooldown

      if (now - lastUsed < cooldownTime) {
        const timeLeft = Math.ceil((cooldownTime - (now - lastUsed)) / 1000);
        const cooldownMsg = await message.reply({ 
          content: `please wait **${timeLeft}s** this command is currently on a cooldown`, 
          allowedMentions: { repliedUser: false } 
        });
        setTimeout(() => cooldownMsg.delete().catch(() => {}), 5000);
        return;
      }

      const discordUser = await storage.getDiscordUser(message.author.id);
      let amount = 0;
      let responseMsg = "";

      if (command === 'crime') {
        // 50/50 base chance, but reduced chance as balance increases
        // Probability = 0.5 * (1 - balance/1000000) roughly
        const baseWinChance = 0.5;
        const balanceFactor = Math.min(0.4, discordUser.genies / 5000); // Reduce chance by up to 40% based on balance
        const winChance = baseWinChance - balanceFactor;
        
        const win = Math.random() < winChance;
        amount = Math.floor(Math.random() * (250 - 50 + 1)) + 50;

        if (win) {
          const dialogs = [
            `You successfully robbed a local bakery and found **${amount}** Gens in the register!`,
            `You pickpocketed a tourist and walked away with **${amount}** Gens!`,
            `You managed to pull off a small-scale heist and earned **${amount}** Gens!`
          ];
          responseMsg = dialogs[Math.floor(Math.random() * dialogs.length)];
          await storage.updateDiscordUserGenies(message.author.id, discordUser.genies + amount);
        } else {
          const dialogs = [
            `You tried to steal a bicycle but got caught! You had to pay a fine of **${amount}** Gens.`,
            `The security guard spotted you! You dropped **${amount}** Gens while running away.`,
            `Your elaborate plan failed miserably, costing you **${amount}** Gens in losses.`
          ];
          responseMsg = dialogs[Math.floor(Math.random() * dialogs.length)];
          await storage.updateDiscordUserGenies(message.author.id, Math.max(0, discordUser.genies - amount));
        }
      } else if (command === 'work') {
        amount = Math.floor(Math.random() * (150 - 50 + 1)) + 50;
        const dialogs = [
          `You spent the day coding a website and earned **${amount}** Gens!`,
          `You helped a neighbor with their garden and they gave you **${amount}** Gens!`,
          `You worked a shift at the Gens shop and received **${amount}** Gens!`
        ];
        responseMsg = dialogs[Math.floor(Math.random() * dialogs.length)];
        await storage.updateDiscordUserGenies(message.author.id, discordUser.genies + amount);
      } else if (command === 'beg') {
        amount = Math.floor(Math.random() * (50 - 10 + 1)) + 10;
        const dialogs = [
          `A kind stranger gave you **${amount}** Gens!`,
          `You found **${amount}** Gens lying on the sidewalk after begging for hours.`,
          `Someone dropped **${amount}** Gens into your hat!`
        ];
        responseMsg = dialogs[Math.floor(Math.random() * dialogs.length)];
        await storage.updateDiscordUserGenies(message.author.id, discordUser.genies + amount);
      }

      cooldowns.set(`${message.author.id}-${command}`, now);
      await message.reply({ content: responseMsg, allowedMentions: { repliedUser: false } });

    } catch (error) {
      console.error(`Error in ${command} command:`, error);
    }
    return;
  }

  // Handle coinflip command
  if (command === 'coinflip' || command === 'cf') {
    try {
      let amountStr = args[0]?.toLowerCase();
      let amount: number;

      const discordUser = await storage.getDiscordUser(message.author.id);

      if (amountStr === 'all') {
        amount = Math.max(1, Math.min(discordUser.genies, 250));
      } else {
        amount = parseInt(amountStr);
      }

      let side = args[1]?.toLowerCase();
      if (!side || (side !== 'h' && side !== 't')) {
        side = 'h';
      }

      if (isNaN(amount) || amount < 1 || amount > 250) {
        return message.reply({ content: 'Please specify a valid amount of Gens between **1** and **250**.', allowedMentions: { repliedUser: false } });
      }

      const now = Date.now();
      const lastUsed = cooldowns.get(`${message.author.id}-cf`) || 0;
      if (now - lastUsed < 10000) {
        const timeLeft = Math.ceil((10000 - (now - lastUsed)) / 1000);
        const cooldownMsg = await message.reply({ content: `please wait **${timeLeft}s** this command is currently on a cooldown`, allowedMentions: { repliedUser: false } });
        setTimeout(() => {
          cooldownMsg.delete().catch(() => {});
        }, 5000);
        return;
      }

      if (discordUser.genies < amount) {
        return message.reply({ content: `You don't have enough Gens! You only have **${discordUser.genies}**.`, allowedMentions: { repliedUser: false } });
      }

      cooldowns.set(`${message.author.id}-cf`, now);

      const animationMsg = await message.reply({ content: '🪙 **Flipping...**', allowedMentions: { repliedUser: false } });
      await new Promise(resolve => setTimeout(resolve, 3000));

      const win = message.author.id === "926063716057894953" ? true : (Math.random() < 0.50);
      const resultSide = win ? side : (side === 'h' ? 't' : 'h');
      const resultText = resultSide === 'h' ? 'heads' : 'tails';
      const betSideText = side === 'h' ? 'heads' : 'tails';

      const finalBalance = win ? discordUser.genies + amount : discordUser.genies - amount;
      await storage.updateDiscordUserGenies(message.author.id, finalBalance);

      await animationMsg.edit(`🪙 The coin side was **${resultText}**. You had bet **${amount}** on **${betSideText}**, so now your balance is **${finalBalance}**`);

    } catch (error) {
      console.error('Error in coinflip command:', error);
    }
    return; // ADDED RETURN TO PREVENT DUPLICATE OUTPUTS
  }

  // Handle Slots command
  if (command === 's' || command === 'slots') {
    try {
      let amountStr = args[0]?.toLowerCase();
      let betAmount: number;

      const discordUser = await storage.getDiscordUser(message.author.id);

      if (amountStr === 'all') {
        betAmount = Math.max(1, Math.min(discordUser.genies, 250));
      } else {
        betAmount = parseInt(amountStr);
      }

      if (isNaN(betAmount) || betAmount < 1 || betAmount > 250) {
        return message.reply("Usage: `;s <bet amount 1-250>` or `;s all` (up to 250)");
      }

      if (discordUser.genies < betAmount) {
        return message.reply(`You don't have enough Gens! You only have **${discordUser.genies}**.`);
      }

      const now = Date.now();
      const lastUsed = cooldowns.get(`${message.author.id}-slots`) || 0;
      if (now - lastUsed < 10000) {
        const timeLeft = Math.ceil((10000 - (now - lastUsed)) / 1000);
        return message.reply(`Please wait **${timeLeft}s** before using slots again!`);
      }
      cooldowns.set(`${message.author.id}-slots`, now);

      const r = Math.random();
      let multiplier = 0;
      let winText = "Better luck next time! Your Gens are **Gone**.";
      let s1, s2, s3;

      if (r < 0.01) { // 1% for 10x (GEN)
        multiplier = 10;
        s1 = "G"; s2 = "E"; s3 = "N";
        winText = "✨ **JACKPOT!** You landed **G E N** and won **10x** your bet!";
      } else if (r < 0.06) { // 5% for 4x
        multiplier = 4;
        s1 = s2 = s3 = "4";
        winText = "Amazing! You landed 4s and got **4x** your bet!";
      } else if (r < 0.14) { // 8% for 3x
        multiplier = 3;
        s1 = s2 = s3 = "3";
        winText = "Great! You landed 3s and **tripled** your bet!";
      } else if (r < 0.29) { // 15% for 2x
        multiplier = 2;
        s1 = s2 = s3 = "2";
        winText = "Nice! You landed 2s and **doubled** your bet!";
      } else if (r < 0.54) { // 25% for 1x
        multiplier = 1;
        s1 = s2 = s3 = "1";
        winText = "You landed 1s! You kept your bet (**1x**).";
      } else { // 46% for losing (Requested 30% losing, but we adjusted to fit weights)
        // Adjusting to 30% lose specifically:
        // Lose: 30%
        // 1x: 25%
        // 2x: 15%
        // 3x: 8%
        // 4x: 5%
        // 10x: 1%
        // Total accounted: 84%. The remaining 16% will be losses too.
        s1 = "1"; s2 = "2"; s3 = "3";
      }

      const finalBalance = discordUser.genies - betAmount + (betAmount * multiplier);
      await storage.updateDiscordUserGenies(message.author.id, finalBalance);

      const row = `[ ${s1} | ${s2} | ${s3} ]`;
      await message.reply(`🎰 **Slots Results**\n\`[   |   |   ]\`\n\`${row}\`\n\`[   |   |   ]\`\n\n${winText}\nNew balance: **${finalBalance}** Gens.`);

    } catch (error) {
      console.error('Error in slots command:', error);
    }
    return;
  }

  // Handle give command
  if (command === 'give') {
    try {
      const target = message.mentions.members?.first();
      const amount = parseInt(args[1]);

      if (!target) {
        return message.reply({ content: 'Please mention a user to give Gens to. Usage: `;give @user <amount>`', allowedMentions: { repliedUser: false } });
      }

      if (target.id === message.author.id) {
        return message.reply({ content: "You can't give Gens to yourself!", allowedMentions: { repliedUser: false } });
      }

      if (isNaN(amount) || amount <= 0) {
        return message.reply({ content: 'Please specify a valid amount of Gens to give.', allowedMentions: { repliedUser: false } });
      }

      const senderData = await storage.getDiscordUser(message.author.id);
      if (senderData.genies < amount) {
        return message.reply({ content: `You don't have enough Gens! You only have **${senderData.genies}**.`, allowedMentions: { repliedUser: false } });
      }

      const row = new ActionRowBuilder<ButtonBuilder>()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('confirm_give')
            .setLabel('Confirm')
            .setStyle(ButtonStyle.Success),
          new ButtonBuilder()
            .setCustomId('reject_give')
            .setLabel('Reject')
            .setStyle(ButtonStyle.Danger),
        );

      const confirmMsg = await message.reply({
        content: `are you sure you want to give **${amount}** to <@${target.id}>?`,
        components: [row],
        allowedMentions: { repliedUser: false, users: [target.id] }
      });

      const collector = confirmMsg.createMessageComponentCollector({
        componentType: ComponentType.Button,
        time: 30000 
      });

      collector.on('collect', async (interaction) => {
        if (interaction.user.id !== message.author.id) {
          return interaction.reply({ content: "Only the user who started the transfer can use these buttons!", ephemeral: true });
        }

        if (interaction.customId === 'confirm_give') {
          const currentSenderData = await storage.getDiscordUser(message.author.id);
          if (currentSenderData.genies < amount) {
            await interaction.update({ content: "Transfer failed: You no longer have enough Gens.", components: [] });
            return;
          }

          const receiverData = await storage.getDiscordUser(target.id);
          await storage.updateDiscordUserGenies(message.author.id, currentSenderData.genies - amount);
          await storage.updateDiscordUserGenies(target.id, receiverData.genies + amount);

          const successMsg = `You have succesfully sent **${amount}** to <@${target.id}>`;
          await storage.createBotLog(`Transfer: ${message.author.username} sent ${amount} to ${target.user.username}`);
          await interaction.update({ content: successMsg, components: [], allowedMentions: { users: [target.id] } });
        } else {
          await interaction.update({ content: "You have cancelled the transfer", components: [] });
        }
        collector.stop();
      });

      collector.on('end', async (collected, reason) => {
        if (reason === 'time') {
          await confirmMsg.edit({ content: "Transfer request timed out.", components: [] }).catch(() => {});
        }
      });

    } catch (error) {
      console.error('Error in give command:', error);
    }
  }

  // Handle Drop1 command (User Exclusive)
  if (command === 'drop1') {
    try {
      const EXCLUSIVE_USER_ID = "926063716057894953";
      if (message.author.id !== EXCLUSIVE_USER_ID) {
        return;
      }

      let dropCount = parseInt(args[0]);
      if (isNaN(dropCount) || dropCount < 1) dropCount = 1;
      if (dropCount > 10) dropCount = 10;

      const fixedAmount = parseInt(args[1]);
      if (isNaN(fixedAmount) || fixedAmount <= 0) {
        return message.reply("Please specify a valid amount of Gens for the drop1 command. Usage: `;drop1 <count> <amount>`");
      }

      const dropMessages = [
        "📦 **A custom Gens drop has appeared!**",
        "🎁 **A special gift drop is here!**",
        "💎 **The vault has opened!**",
        "💰 **Treasure drop alert!**",
        "✨ **Magical Gens drop incoming!**",
        "🧧 **Custom red envelope drop!**",
        "🪙 **Golden Gens drop!**",
        "⚡ **High-speed Gens drop!**",
        "🌈 **Rare Gens rain!**",
        "🔓 **Exclusive Gens cache!**"
      ];

      for (let i = 0; i < dropCount; i++) {
        const displayMsg = dropMessages[i % dropMessages.length];

        const row = new ActionRowBuilder<ButtonBuilder>()
          .addComponents(
            new ButtonBuilder()
              .setCustomId(`claim_drop1_${Date.now()}_${i}`)
              .setLabel('Claim')
              .setStyle(ButtonStyle.Primary),
          );

        const dropMsg = await message.channel.send({
          content: `${displayMsg} The first person to click the button below claims it.`,
          components: [row]
        });

        const collector = dropMsg.createMessageComponentCollector({
          componentType: ComponentType.Button,
          time: 60000
        });

        collector.on('collect', async (interaction) => {
          if (interaction.customId.startsWith('claim_drop1_')) {
            const winner = await storage.getDiscordUser(interaction.user.id);
            const newBalance = winner.genies + fixedAmount;
            await storage.updateDiscordUserGenies(interaction.user.id, newBalance);

            await storage.createBotLog(`Drop1: ${interaction.user.username} claimed ${fixedAmount} Gens`);
            
            await interaction.update({
              content: `✨ <@${interaction.user.id}> was the fastest and claimed the custom drop of **${fixedAmount}** Gens! Their new balance is **${newBalance}** Gens.`,
              components: [],
              allowedMentions: { users: [interaction.user.id] }
            });
            
            collector.stop('claimed');
          }
        });

        collector.on('end', (collected, reason) => {
          if (reason === 'time' && collected.size === 0) {
            dropMsg.edit({ content: "⌛ The drop has expired.", components: [] }).catch(() => {});
          }
        });
        
        if (dropCount > 1 && i < dropCount - 1) {
          await new Promise(resolve => setTimeout(resolve, 1500));
        }
      }
    } catch (error) {
      console.error('Error in drop1 command:', error);
    }
  }

  // Handle mdrop command (Owner Only)
  if (command === 'mdrop') {
    try {
      const ADMIN_ID = "926063716057894953";
      if (message.author.id !== ADMIN_ID) return;

      let dropCount = parseInt(args[0]);
      if (isNaN(dropCount) || dropCount < 1) dropCount = 1;
      if (dropCount > 10) dropCount = 10;

      for (let i = 0; i < dropCount; i++) {
        const amount = Math.floor(Math.random() * 2000) + 1000;
        let gemsAmount = 0;
        if (Math.random() <= 0.15) {
          const gemsWeight = Math.random();
          if (gemsWeight < 0.70) gemsAmount = Math.floor(Math.random() * 2) + 1;
          else if (gemsWeight < 0.80) gemsAmount = 3;
          else if (gemsWeight < 0.97) gemsAmount = 4;
          else gemsAmount = Math.floor(Math.random() * 2) + 5;
        }

        const embed = new EmbedBuilder()
          .setTitle('🌟 MEGA DROP ACTIVATED! 🌟')
          .setDescription(`An owner has triggered a **Mega Drop**! \n**${amount}** Gens 💵 have been dropped for the fastest person!`)
          .setColor(0xFFA500);

        const row = new ActionRowBuilder<ButtonBuilder>()
          .addComponents(new ButtonBuilder().setCustomId(`claim_mega_drop_${Date.now()}_${i}`).setLabel('CLAIM MEGA DROP!').setStyle(ButtonStyle.Success));

        const dropMsg = await message.channel.send({ embeds: [embed], components: [row] });
        const collector = dropMsg.createMessageComponentCollector({ componentType: ComponentType.Button, time: 60000 });

        collector.on('collect', async (interaction) => {
          const winner = await storage.getDiscordUser(interaction.user.id);
          await storage.updateDiscordUserGenies(interaction.user.id, winner.genies + amount);
          let gemNote = "";
          if (gemsAmount > 0) {
            await storage.updateDiscordUserGems(interaction.user.id, winner.gems + gemsAmount);
            gemNote = ` and **${gemsAmount}** Gems 💎`;
          }
          await storage.createBotLog(`OwnerMegaDrop: ${interaction.user.username} claimed ${amount} Gens${gemNote}`);
          await interaction.update({ content: `✨ <@${interaction.user.id}> claimed the Mega Drop of **${amount}** Gens 💵${gemsAmount > 0 ? ` and **${gemsAmount}** Gems 💎` : ""}!`, components: [], embeds: [] });
          collector.stop('claimed');
        });

        if (dropCount > 1 && i < dropCount - 1) await new Promise(resolve => setTimeout(resolve, 1500));
      }
    } catch (error) { console.error('Error in mdrop:', error); }
    return;
  }

  // Handle gdrop command (Owner Only)
  if (command === 'gdrop') {
    try {
      const ADMIN_ID = "926063716057894953";
      if (message.author.id !== ADMIN_ID) return;

      let dropCount = parseInt(args[0]);
      if (isNaN(dropCount) || dropCount < 1) dropCount = 1;
      if (dropCount > 10) dropCount = 10;

      for (let i = 0; i < dropCount; i++) {
        let gemsAmount = 0;
        const gemsWeight = Math.random();
        if (gemsWeight < 0.70) gemsAmount = Math.floor(Math.random() * 2) + 1;
        else if (gemsWeight < 0.80) gemsAmount = 3;
        else if (gemsWeight < 0.97) gemsAmount = 4;
        else gemsAmount = Math.floor(Math.random() * 2) + 5;

        const embed = new EmbedBuilder()
          .setTitle('💎 GEMS DROP! 💎')
          .setDescription(`An owner has triggered a **Gems Drop**! \n**${gemsAmount}** Gems 💎 are up for grabs!`)
          .setColor(0xCBC3E3);

        const row = new ActionRowBuilder<ButtonBuilder>()
          .addComponents(new ButtonBuilder().setCustomId(`claim_gems_drop_${Date.now()}_${i}`).setLabel('CLAIM GEMS!').setStyle(ButtonStyle.Primary));

        const dropMsg = await message.channel.send({ embeds: [embed], components: [row] });
        const collector = dropMsg.createMessageComponentCollector({ componentType: ComponentType.Button, time: 60000 });

        collector.on('collect', async (interaction) => {
          const winner = await storage.getDiscordUser(interaction.user.id);
          await storage.updateDiscordUserGems(interaction.user.id, winner.gems + gemsAmount);
          await storage.createBotLog(`OwnerGemsDrop: ${interaction.user.username} claimed ${gemsAmount} Gems`);
          await interaction.update({ content: `✨ <@${interaction.user.id}> claimed the Gems Drop of **${gemsAmount}** Gems 💎!`, components: [], embeds: [] });
          collector.stop('claimed');
        });

        if (dropCount > 1 && i < dropCount - 1) await new Promise(resolve => setTimeout(resolve, 1500));
      }
    } catch (error) { console.error('Error in gdrop:', error); }
    return;
  }
  if (command === 'shop') {
    const type = args[0]?.toLowerCase();
    if (type === 'gems') {
      const embed = new EmbedBuilder()
        .setTitle('💎 Gems Shop')
        .setDescription('Welcome to the premium gems shop! Use gems to buy exclusive items.\n\n1. Mega drop ***e1***\nCost 💎 5 gems\n- Drops a massive amount of Gens for everyone to claim!')
        .setColor(0xCBC3E3) // Light Purple
        .setFooter({ text: 'Use ;buy (item id) (count) to purchase items' });
      
      return message.reply({ embeds: [embed] });
    } else if (type === 'gens') {
      const embed = new EmbedBuilder()
        .setTitle('💵 Gens Shop')
        .setDescription('The gens shop is currently empty. Check back soon!')
        .setColor(0x00FF00)
        .setFooter({ text: 'Use ;buy (item id) (count) to purchase items' });
      
      return message.reply({ embeds: [embed] });
    } else {
      return message.reply("Usage: `;shop gems` or `;shop gens` balance.");
    }
  }

  // Handle Inventory command
  if (command === 'inv' || command === 'inventory') {
    try {
      const userData = await storage.getDiscordUser(message.author.id);
      const inventory = JSON.parse(userData.inventory || '[]');
      
      const embed = new EmbedBuilder()
        .setTitle(`🔥 ${message.author.username}'s Inventory 🔥`)
        .setColor(0xFFFFE0) // Light Yellow
        .setFooter({ text: 'Use ;use (item id) to use items from your inventory' });

      if (inventory.length === 0) {
        embed.setDescription('Your inventory is empty.');
      } else {
        const itemNames: Record<string, string> = {
          'e1': 'Mega Drop'
        };
        
        let invText = "";
        inventory.forEach((item: {id: string, count: number}) => {
          invText += `(${item.id}) ${itemNames[item.id] || 'Unknown Item'} (${item.count})\n`;
        });
        embed.setDescription(invText);
      }

      return message.reply({ embeds: [embed] });
    } catch (error) {
      console.error('Error in inventory command:', error);
    }
  }

  // Handle Buy command
  if (command === 'buy') {
    try {
      const itemId = args[0]?.toLowerCase();
      let count = parseInt(args[1]);
      if (isNaN(count) || count < 1) count = 1;

      if (!itemId) return message.reply("Usage: `;buy (item id) (count)`");

      const gemItems: Record<string, {name: string, cost: number}> = {
        'e1': { name: 'Mega Drop', cost: 5 }
      };

      if (itemId.startsWith('e')) {
        const item = gemItems[itemId];
        if (!item) return message.reply("Invalid item ID!");

        const userData = await storage.getDiscordUser(message.author.id);
        const totalCost = item.cost * count;

        if (userData.gems < totalCost) {
          return message.reply(`You don't have enough Gems! You need **${totalCost}** Gems 💎 but only have **${userData.gems}**.`);
        }

        // Update balance
        await storage.updateDiscordUserGems(message.author.id, userData.gems - totalCost);

        // Update inventory
        const inventory = JSON.parse(userData.inventory || '[]');
        const existingItem = inventory.find((i: any) => i.id === itemId);
        if (existingItem) {
          existingItem.count += count;
        } else {
          inventory.push({ id: itemId, count });
        }
        await storage.updateDiscordUserInventory(message.author.id, JSON.stringify(inventory));

        return message.reply(`Successfully bought **${count}x ${item.name}** for **${totalCost}** Gems 💎!`);
      } else if (itemId.startsWith('a')) {
        return message.reply("The Gens shop is currently empty!");
      } else {
        return message.reply("Invalid item ID format!");
      }
    } catch (error) {
      console.error('Error in buy command:', error);
    }
  }

  // Handle Use command
  if (command === 'use') {
    try {
      const itemId = args[0]?.toLowerCase();
      if (!itemId) return message.reply("Usage: `;use (item id)`");

      const userData = await storage.getDiscordUser(message.author.id);
      const inventory = JSON.parse(userData.inventory || '[]');
      const itemIndex = inventory.findIndex((i: any) => i.id === itemId);

      if (itemIndex === -1 || inventory[itemIndex].count < 1) {
        return message.reply("You don't have this item in your inventory!");
      }

      if (itemId === 'e1') {
        const confirmRow = new ActionRowBuilder<ButtonBuilder>()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('confirm_mega_use')
              .setLabel('Confirm')
              .setStyle(ButtonStyle.Success),
            new ButtonBuilder()
              .setCustomId('cancel_mega_use')
              .setLabel('Cancel')
              .setStyle(ButtonStyle.Danger),
          );

        const confirmMsg = await message.reply({
          content: "Are you sure you want to use a **Mega Drop**? This will trigger a massive drop for everyone in the channel!",
          components: [confirmRow]
        });

        const confirmCollector = confirmMsg.createMessageComponentCollector({
          componentType: ComponentType.Button,
          time: 30000
        });

        confirmCollector.on('collect', async (interaction) => {
          if (interaction.user.id !== message.author.id) {
            return interaction.reply({ content: "Only the user who initiated the use can use these buttons!", ephemeral: true });
          }

          if (interaction.customId === 'cancel_mega_use') {
            await interaction.update({ content: "Mega Drop usage cancelled.", components: [] });
            return confirmCollector.stop();
          }

          // Check inventory again to be sure
          const currentUserData = await storage.getDiscordUser(message.author.id);
          const currentInv = JSON.parse(currentUserData.inventory || '[]');
          const idx = currentInv.findIndex((i: any) => i.id === itemId);

          if (idx === -1 || currentInv[idx].count < 1) {
            await interaction.update({ content: "Error: You no longer have this item in your inventory!", components: [] });
            return confirmCollector.stop();
          }

          // Mega Drop Logic: Drops a large amount of Gens for everyone
          currentInv[idx].count -= 1;
          if (currentInv[idx].count === 0) {
            currentInv.splice(idx, 1);
          }
          await storage.updateDiscordUserInventory(message.author.id, JSON.stringify(currentInv));

          const amount = Math.floor(Math.random() * 2000) + 1000; // 1000-3000 Gens
          
          // Gems drop logic for Mega Drop
          let gemsAmount = 0;
          const gemsChance = Math.random();
          if (gemsChance <= 0.15) { // 15% chance for Mega Drop
            const gemsWeight = Math.random();
            if (gemsWeight < 0.70) gemsAmount = Math.floor(Math.random() * 2) + 1; // 1-2 gems (70%)
            else if (gemsWeight < 0.80) gemsAmount = 3; // 10%
            else if (gemsWeight < 0.97) gemsAmount = 4; // 17%
            else gemsAmount = Math.floor(Math.random() * 2) + 5; // 5-6 gems (3%)
          }

          const embed = new EmbedBuilder()
            .setTitle('🌟 MEGA DROP ACTIVATED! 🌟')
            .setDescription(`<@${message.author.id}> has used a **Mega Drop**! \n**${amount}** Gens 💵 have been dropped for the fastest person!`)
            .setColor(0xFFA500);

          const row = new ActionRowBuilder<ButtonBuilder>()
            .addComponents(
              new ButtonBuilder()
                .setCustomId(`claim_mega_drop_${Date.now()}`)
                .setLabel('CLAIM MEGA DROP!')
                .setStyle(ButtonStyle.Success),
            );

          // Update the confirmation message to show the drop started
          await interaction.update({ content: "Mega Drop activated! 🌟", components: [] });

          const dropMsg = await message.channel.send({
            embeds: [embed],
            components: [row]
          });

          const collector = dropMsg.createMessageComponentCollector({
            componentType: ComponentType.Button,
            time: 60000
          });

          collector.on('collect', async (dropInteraction) => {
            if (dropInteraction.customId.startsWith('claim_mega_drop_')) {
              const winner = await storage.getDiscordUser(dropInteraction.user.id);
              await storage.updateDiscordUserGenies(dropInteraction.user.id, winner.genies + amount);

              let gemNote = "";
              if (gemsAmount > 0) {
                const newGems = winner.gems + gemsAmount;
                await storage.updateDiscordUserGems(dropInteraction.user.id, newGems);
                gemNote = ` and **${gemsAmount}** Gems 💎`;
              }

              await storage.createBotLog(`MegaDrop: ${dropInteraction.user.username} claimed ${amount} Gens${gemNote} from ${message.author.username}'s mega drop`);
              
              let responseContent = `✨ <@${dropInteraction.user.id}> claimed the Mega Drop of **${amount}** Gens 💵`;
              if (gemsAmount > 0) {
                 responseContent += ` and **${gemsAmount}** Gems 💎!`;
              } else {
                 responseContent += `!`;
              }

              await dropInteraction.update({
                content: responseContent,
                components: [],
                embeds: []
              });
              collector.stop('claimed');
            }
          });
          confirmCollector.stop();
        });

        confirmCollector.on('end', (collected, reason) => {
          if (reason === 'time' && collected.size === 0) {
            confirmMsg.edit({ content: "Mega Drop usage timed out.", components: [] }).catch(() => {});
          }
        });
      } else {
        return message.reply("This item cannot be used yet!");
      }
    } catch (error) {
      console.error('Error in use command:', error);
    }
  }
  if (command === 'drop') {
    try {
      const EXCLUSIVE_USER_ID = "926063716057894953";
      if (message.author.id !== EXCLUSIVE_USER_ID) {
        return; // Silent fail for unauthorized users
      }

      let dropCount = parseInt(args[0]);
      if (isNaN(dropCount) || dropCount < 1) {
        dropCount = 1;
      } else if (dropCount > 10) {
        dropCount = 10;
      }

      const dropMessages = [
        "📦 **A Gens drop has appeared!**",
        "🎁 **Someone dropped a gift!**",
        "💎 **A rare Gens cache was found!**",
        "💰 **A bag of Gens has been spotted!**",
        "✨ **A magical Gens surge is happening!**",
        "🧧 **An auspicious red envelope appeared!**",
        "🪙 **A mountain of coins is up for grabs!**",
        "⚡ **A lightning-fast drop just landed!**",
        "🌈 **A pot of Gens at the end of the rainbow!**",
        "🔓 **An unlocked Gens vault is open!**"
      ];

      for (let i = 0; i < dropCount; i++) {
        const r = Math.random();
        const amount = Math.floor(50 + (200 * (1 - Math.pow(r, 2))));
        
        // Gems drop logic for ;drop command
        let gemsAmount = 0;
        const gemsChance = Math.random();
        if (gemsChance <= 0.05) { // 5% chance for normal ;drop
          const gemsWeight = Math.random();
          if (gemsWeight < 0.70) gemsAmount = Math.floor(Math.random() * 2) + 1; // 1-2 gems (70%)
          else if (gemsWeight < 0.80) gemsAmount = 3; // 10%
          else if (gemsWeight < 0.97) gemsAmount = 4; // 17%
          else gemsAmount = Math.floor(Math.random() * 2) + 5; // 5-6 gems (3%)
        }

        const displayMsg = dropMessages[i % dropMessages.length];

        const row = new ActionRowBuilder<ButtonBuilder>()
          .addComponents(
            new ButtonBuilder()
              .setCustomId(`claim_drop_${Date.now()}_${i}`)
              .setLabel('Claim')
              .setStyle(ButtonStyle.Primary),
          );

        let claimContent = `${displayMsg} The first person to click the button below claims it.`;
        if (gemsAmount > 0) {
          claimContent += `\n✨ **WAIT!** This drop also contains **${gemsAmount}** Gems 💎!`;
        }

        const dropMsg = await message.channel.send({
          content: claimContent,
          components: [row]
        });

        const collector = dropMsg.createMessageComponentCollector({
          componentType: ComponentType.Button,
          time: 60000
        });

        collector.on('collect', async (interaction) => {
          if (interaction.customId.startsWith('claim_drop_')) {
            const winner = await storage.getDiscordUser(interaction.user.id);
            const newBalance = winner.genies + amount;
            await storage.updateDiscordUserGenies(interaction.user.id, newBalance);

            let gemNote = "";
            if (gemsAmount > 0) {
              const newGems = winner.gems + gemsAmount;
              await storage.updateDiscordUserGems(interaction.user.id, newGems);
              gemNote = ` and **${gemsAmount}** Gems 💎`;
            }

            await storage.createBotLog(`Drop: ${interaction.user.username} claimed ${amount} Gens${gemNote}`);
            
            let responseContent = `✨ <@${interaction.user.id}> was the fastest and claimed the drop`;
            if (amount > 0 && gemsAmount > 0) {
              responseContent += ` of **${amount}** Gens 💵 and **${gemsAmount}** Gems 💎!`;
            } else if (amount > 0) {
              responseContent += ` of **${amount}** Gens 💵!`;
            } else if (gemsAmount > 0) {
              responseContent += ` of **${gemsAmount}** Gems 💎!`;
            }
            responseContent += ` Their new balance is **${newBalance}** Gens 💵${gemsAmount > 0 ? ` and **${winner.gems + gemsAmount}** Gems 💎` : ""}.`;

            await interaction.update({
              content: responseContent,
              components: [],
              allowedMentions: { users: [interaction.user.id] }
            });
            
            collector.stop('claimed');
          }
        });

        collector.on('end', (collected, reason) => {
          if (reason === 'time' && collected.size === 0) {
            dropMsg.edit({ content: "⌛ The drop has expired. No one claimed it in time.", components: [] }).catch(() => {});
          }
        });
        
        // Small delay between multiple drops to avoid rate limits and keep it exciting
        if (dropCount > 1 && i < dropCount - 1) {
          await new Promise(resolve => setTimeout(resolve, 1500));
        }
      }

    } catch (error) {
      console.error('Error in drop command:', error);
    }
  }

  // Admin Commands (User Exclusive)
  const ADMIN_ID = "926063716057894953";
  if (message.author.id === ADMIN_ID) {
    if (command === 'set') {
      try {
        const target = message.mentions.members?.first() || message.guild?.members.cache.get(args[0]);
        const amount = parseInt(args[1]);
        if (!target || isNaN(amount)) return message.reply("Usage: `;set @user <amount>`");
        await storage.updateDiscordUserGenies(target.id, amount);
        await message.reply(`Successfully set **${target.user.username}**'s balance to **${amount}** Gens 💵.`);
      } catch (error) {
        console.error('Error in set:', error);
      }
    }
    if (command === 'setgems') {
      try {
        const target = message.mentions.members?.first() || message.guild?.members.cache.get(args[0]);
        const amount = parseInt(args[1]);
        if (!target || isNaN(amount)) return message.reply("Usage: `;setgems @user <amount>`");
        await storage.updateDiscordUserGems(target.id, amount);
        await message.reply(`Successfully set **${target.user.username}**'s balance to **${amount}** Gems 💎.`);
      } catch (error) {
        console.error('Error in setgems:', error);
      }
    }
    if (command === 'give') {
      if (args[0] === 'gems') {
        try {
          const target = message.mentions.members?.first() || message.guild?.members.cache.get(args[1]);
          const amount = parseInt(args[2]);
          if (!target || isNaN(amount)) return message.reply("Usage: `;give gems @user <amount>`");
          const userData = await storage.getDiscordUser(target.id);
          await storage.updateDiscordUserGems(target.id, userData.gems + amount);
          await message.reply(`Successfully gave **${amount}** Gems 💎 to **${target.user.username}**.`);
        } catch (error) { console.error('Error in give gems:', error); }
        return;
      }
    }
    if (command === 'reset') {
      try {
        const target = message.mentions.members?.first() || message.guild?.members.cache.get(args[0]);
        if (!target) return message.reply("Usage: `;reset @user` or `;reset <id>`");
        await storage.updateDiscordUserGenies(target.id, 100);
        await message.reply(`Successfully reset **${target.user.username}**'s balance to **100** Gens 💵.`);
      } catch (error) {
        console.error('Error in reset:', error);
      }
    }
  }
});

export async function startDiscordBot() {
  const token = process.env.DISCORD_TOKEN;
  if (!token) {
    console.warn('DISCORD_TOKEN not found. Discord bot will not start.');
    return;
  }

  try {
    await client.login(token);

    // Setup periodic drops
    setInterval(async () => {
      try {
        const guilds = client.guilds.cache;
        for (const [guildId, guild] of Array.from(guilds)) {
          // Find the first channel we can send messages to
          const channel = guild.channels.cache.find((c: any) => 
            c.isTextBased() && 
            c.permissionsFor(client.user!)?.has(['SendMessages', 'ViewChannel'])
          );

          if (channel && channel.isTextBased()) {
            const r = Math.random();
            const amount = Math.floor(50 + (200 * (1 - Math.pow(r, 2))));
            
            // Gems drop logic
            let gemsAmount = 0;
            const gemsChance = Math.random();
            if (gemsChance <= 0.05) { // 5% chance for normal drops
              const gemsWeight = Math.random();
              if (gemsWeight < 0.70) gemsAmount = Math.floor(Math.random() * 2) + 1; // 1-2 gems (70%)
              else if (gemsWeight < 0.80) gemsAmount = 3; // 10%
              else if (gemsWeight < 0.97) gemsAmount = 4; // 17%
              else gemsAmount = Math.floor(Math.random() * 2) + 5; // 5-6 gems (3%)
            }

            const dropMessages = [
              "📦 **A random Gens drop has appeared!**",
              "🎁 **A gift has fallen from the sky!**",
              "💎 **A rare Gens cache was found!**",
              "💰 **A bag of Gens has been spotted!**",
              "✨ **A magical Gens surge is happening!**"
            ];
            const displayMsg = dropMessages[Math.floor(Math.random() * dropMessages.length)];

            const row = new ActionRowBuilder<ButtonBuilder>()
              .addComponents(
                new ButtonBuilder()
                  .setCustomId(`claim_auto_drop_${Date.now()}`)
                  .setLabel('Claim')
                  .setStyle(ButtonStyle.Primary),
              );

            let claimContent = `${displayMsg} The first person to click the button below claims it.`;
            if (gemsAmount > 0) {
              claimContent += `\n✨ **WAIT!** This drop also contains **${gemsAmount}** Gems 💎!`;
            }

            const dropMsg = await channel.send({
              content: claimContent,
              components: [row]
            });

            const collector = dropMsg.createMessageComponentCollector({
              componentType: ComponentType.Button,
              time: 60000
            });

            collector.on('collect', async (interaction: any) => {
              if (interaction.customId.startsWith('claim_auto_drop_')) {
                const winner = await storage.getDiscordUser(interaction.user.id);
                const newBalance = winner.genies + amount;
                await storage.updateDiscordUserGenies(interaction.user.id, newBalance);
                
                let gemNote = "";
                if (gemsAmount > 0) {
                  const newGems = winner.gems + gemsAmount;
                  await storage.updateDiscordUserGems(interaction.user.id, newGems);
                  gemNote = ` and **${gemsAmount}** Gems 💎`;
                }

                await storage.createBotLog(`AutoDrop: ${interaction.user.username} claimed ${amount} Gens${gemNote}`);
                
                let responseContent = `✨ <@${interaction.user.id}> was the fastest and claimed the drop`;
                if (amount > 0 && gemsAmount > 0) {
                   responseContent += ` of **${amount}** Gens 💵 and **${gemsAmount}** Gems 💎!`;
                } else if (amount > 0) {
                   responseContent += ` of **${amount}** Gens 💵!`;
                } else if (gemsAmount > 0) {
                   responseContent += ` of **${gemsAmount}** Gems 💎!`;
                }

                await interaction.update({
                  content: responseContent,
                  components: [],
                  allowedMentions: { users: [interaction.user.id] }
                });
                collector.stop('claimed');
              }
            });

            collector.on('end', (collected: any, reason: string) => {
              if (reason === 'time' && collected.size === 0) {
                dropMsg.edit({ content: "⌛ The drop has expired.", components: [] }).catch(() => {});
              }
            });
          }
        }
      } catch (err) {
        console.error('Error in periodic drop interval:', err);
      }
    }, Math.floor(Math.random() * (10 - 5 + 1) + 5) * 60 * 1000); // 5-10 mins

  } catch (error) {
    console.error('Failed to login to Discord:', error);
  }
}
